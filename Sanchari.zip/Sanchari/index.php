
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <?php
 include 'link.php';
 ?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}
.heading{
font-size: 47px;
color:white;
}

.topnav a {
  float: right;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #04AA6D;
  color: white;
}
.para{
    
    font-size: 30px;
    text-align: center;
}
.imaf{
   width: 150px;
   height: 150px;
}
</style>
</head>
<body style="background-color:powderblue;">
<div class="topnav">
  <p class="heading">Online Ambulance</p>
  <a  href="index.php">Home</a>
  <a href="about.php">About Us</a>
  <a href="user/login.php">Login</a>
  <a href="user/register.php">Signup</a>
  <a  href="admin/adminlogin.php">Admin-login</a>
</div>
 <p class="para">Ambulance place a very crucial role when an accident occurs on<br/>
        the road network or in case of any medical emergency and the need<br/>
arises to save a human life. In this project an web application namely<br/>
Online Ambulance Booking Service has been developed. It’s a<br/><!-- comment -->
unique idea in itself in which one can book an ambulance using web<br/>
application.<!-- comment -->
    So Register now
   <br/><!-- comment -->
   <img class="imaf" src="am2.jfif"><br /><!-- comment -->
   <button><strong>Sing-up</strong></button></p>
    

</body>
</html>
