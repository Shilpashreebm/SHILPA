
<html>
    <head> 
        <style>
            #button1 {
                background-color:powderblue;
            } /* Black */
        </style>
        <?php
     include 'link.php';
     ?>
         <?php 
          
session_start(); 
$con = mysqli_connect('localhost', 'root', '', 'ambulance');
   echo'wel';
 
if(isset($_POST['submit'])){
       $name  = $_POST['username'];
       $pass = $_POST['password'];
    
        echo'wel';

        $sql = "SELECT  `uname`, `password` FROM `user` WHERE uname='$name' And password=$pass;";

        $result = mysqli_query($con, $sql);
        echo 'cone';
        
        if (mysqli_num_rows($result) === 1) {

            $row = mysqli_fetch_assoc($result);

            if ($row['user_name'] === $uname && $row['password'] === $pass) {

                echo "Logged in!";

                $_SESSION['user_name'] = $row['user_name'];
                     
                $_SESSION['name'] = $row['name'];

                $_SESSION['id'] = $row['id'];

                header("Location: userhome.php");

                exit();

            }
            else{
                echo 'loginfailed';
            }

        }else{
            echo 'loginfailed';
        }

    }
    if(isset($_POST['HOME'])){
        header("Location: http://localhost/Sanchari/index.php");
    }
    if(isset($_POST['regis'])){
        header("Location: register.php");
        
    }
   ?>
    </head>
    
    <body style="background-color:powderblue;">
        <div id="login">
            <h3 class="text-center text-white pt-5">Online Ambulance</h3>
            <div class="container">
                <div id="login-row" class="row justify-content-center align-items-center">
                    <div id="login-column" class="col-md-6">
                        <div id="login-box" class="col-md-12">
                            <form id="login-form" class="form" action="login.php" method="POST">
                                <h3 class="text-center text-info"> User Login</h3>
 
                                <div class="form-group">
                                    <label for="username" class="text-info">Username:</label><br>
                                    <input type="text" name="username" id="username" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label for="password" class="text-info">Password:</label><br>
                                    <input type="password" name="password" id="password" class="form-control">
                                </div>

                                <div>
                                    <button id="button1" class="from-group" name="submit">Submit</button>
                                </div>
                                <div id="register-link" class="text-right">
                                    <button name="regis" value="Regiseter">Register</button>
                                    <center>  <button id="button1" value="HOME" name="HOME">Home</button></center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
    </body>
</html>
