<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<html>
    <body style="background-color:powderblue;">
<div class="main-div">
    <div class="table-responsive" class="card-body">
        <div class="table-responsive">
            <table class="table">
                <thead>
                <h1> Vehicle available are</h1>
                    <tr>
                        <th> SL No</th>
                        <th scope="col">Vehicle Name</th>
                        <th scope="col">Vehicle Type</th>
                        <th scope="col">Facilities</th>
                         <th scope="col">Select</th>
                    </tr>
                </thead>
                <tbody>
                   <?php 
                    $con = mysqli_connect('localhost', 'root', '', 'ambulance');
                    $query = mysqli_query($con, "SELECT`vname`, `vtype`, `facilities` FROM `vehicle`;");
                    $sl=0;
                            while($row=mysqli_fetch_array($query)){
                             
                            $sl++;
                   ?>
                    <tr>
                        <td><?php echo $sl;?></td>
                        <td> <?php echo $row['vname'];?></td>
                        <td> <?php echo $row['vtype'];?></td>
                        <td> <?php echo $row['facilities'];?></td>
                        
                    </tr>
                            <?php }?>
                </tbody>
            </table>
        </div>
    </div>
    <div>
        <center> <button name="submit" id="name" value="book">Book
            
            </button></center>
    </div>
    </body>
    </html>     
 