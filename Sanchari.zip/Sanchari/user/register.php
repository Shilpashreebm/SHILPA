

<!doctype html>
<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
<html>
    <head>
        <?php
     include 'link.php';
     ?>
        <title> User Registration</title>
        
    </head>
    <body style="background-color:powderblue;">
        <div>
            <?php
            session_start();
           $con = mysqli_connect('localhost', 'root', '', 'ambulance');
           if($con){
            if(isset($_POST['create'])){
                $name1  = $_POST['name'];
                $emailid1 = $_POST['email'];
                $password = $_POST['pass'];
                $num1 = $_POST['num'];
                $addr1 = $_POST['addr'];
                $sql = "INSERT INTO `user`(`uname`, `emailid`, `password`, `phonenum`, `address`) VALUES ('$name1','$emailid1','$password','$num1','$addr1')";
                
                if(mysqli_query($con, $sql)){  
                    echo 'success';
                }
                else{
                    echo 'not sucess';
                }
             }
           }
           else{
               echo 'byee';
           }
            ?>
        </div>
        <div>
            <form action="register.php" method="POST">
                <div class="container">
                    <div class="row"><!-- comment -->
                        <div class="col-sm-3">
                    <h1> User Registration</h1>
                    <p> Fill up the form</p>
                    <hr class="mb-3">
                    <label for="name"><b>Name</b></label>
                    <input class="form-control" type="text" name="name" required><br/><br/>
                     <label for="email"><b>Email-id</b></label>
                     <input class="form-control" type="email" name="email" required><br/><br/>
                     <label for="pass"><b>Password</b></label>
                     <input  class="form-control" type="password" name="pass" required><br/><br/>
                      <label for="num"><b>Number</b></label>
                      <input class="form-control" type="text" name="num" required><br/><br/>
                       <label for="addr"><b>Address</b></label>
                    <input class="form-control" type="text" name="addr" required><br/>
                                        <hr class="mb-3">

                    <input type="submit" name="create" value="Regiseter">
                   
                </div>
            </form>
        </div>
                </div>
        </div>
        
    </body>
</html>