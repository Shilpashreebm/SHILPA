<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 <?php
  session_start();
        $con = mysqli_connect('localhost', 'root', '', 'ambulance');
      if(isset($_POST['add'])){
    header("Location: http://localhost/Sanchari/admin/ambulance.php");
    
}
 if(isset($_POST['allot'])){
    header("Location: http://localhost/Sanchari/admin/ambulance.php");
    
}
 if(isset($_POST['add'])){
    header("Location: http://localhost/Sanchari/admin/ambulance.php");
    
}
 if(isset($_POST['add'])){
    header("Location: http://localhost/Sanchari/admin/ambulance.php");
    
}
 if(isset($_POST['add'])){
    header("Location: http://localhost/Sanchari/admin/ambulance.php");
    
}
?>
<html>

    <body style="background-color:powderblue;">
    <center><div id="login">
            <h3 class="text-center text-white pt-5">Online Ambulance</h3>
            <div class="container">
                <div id="login-row" class="row justify-content-center align-items-center">
                    <div id="login-column" class="col-md-6">
                        <div id="login-box" class="col-md-12">
                            <form id="login-form" class="form" action="adminhome.php" method="POST">
                                <h3 class="text-center text-info"> Admin Home Page</h3>

                                <div class="form-group">
                                    <label for="add" class="text-info">Add Ambulance:</label>
                                    <input type="submit" name="add" id="add" class="form-control">
                                </div><br>
                                <div class="form-group">
                                    <label for="del" class="text-info">Delete Ambulance:</label>
                                    <input type="submit" name="del" id="del" class="form-control">
                                </div><br>
                            <div class="form-group">
                                    <label for="Allot" class="text-info">Allot Ambulance:</label>
                                    <input type="submit" name="allot" id="allot" class="form-control">
                                </div><br>
                                <div class="form-group">
                                    <label for="req" class="text-info">View Request:</label>
                                    <input type="submit" name="req" id="req" class="form-control">
                                </div><br>
                                <div class="form-group">
                                    <label for="app" class="text-info">Approved Request:</label>
                                    <input type="submit" name="app" id="app" class="form-control">
                                </div><!-- comment --><br>
                                <div class="form-group">
                                    <label for="status" class="text-info">Status:</label>
                                    <input type="submit" name="status" id="status" class="form-control">
                                </div><!-- comment --><br>
                                <div>
                                    <button id="button1" class="from-group" name="submit">Submit</button>
                                </div><br>
                                <div id="register-link" class="text-right">
                                    <button name="regis" value="Regiseter">Register</button><br>
                                    <center>  <button id="button1" value="HOME" name="HOME">Home</button></center>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div> </center>
    </body>
    
</html>